# Canal WebView (Android)

Projeto Android Studio simples que abre o endereço configurado em `CHANNEL_URL` dentro de uma WebView, com suporte básico a vídeo em tela cheia.

## Como gerar o APK
1. Instale o Android Studio.
2. Abra a pasta `CanalWebView` como projeto.
3. Aguarde a sincronização do Gradle.
4. Selecione **Build > Build APK(s)**.
5. O APK de depuração normalmente fica em `app/build/outputs/apk/debug/app-debug.apk`.

## Alterar o endereço
Edite a constante `CHANNEL_URL` em `app/src/main/java/com/example/canalwebview/MainActivity.java`.

Observação: o aplicativo apenas exibe um site externo. A disponibilidade, compatibilidade e autorização para retransmissão do conteúdo dependem do site e dos respectivos titulares de direitos. Não inclui nem hospeda o vídeo.
